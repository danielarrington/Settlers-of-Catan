#include <iostream>
#include <vector>
#include "tile.h"

using namespace std;

void buildIsland(vector<Tile*> &island, int size)
{
    for (int i = 0; i < (size * size); i++)
    {
        island.push_back(new EmptyTile(FOREST, (rand() % 11 + 2)));
    }
}

void renderIsland(vector<Tile*> island, int size)
{
    for (int s = 0; s <= size; s++)
    {
        for (int i = 0; i <= 6; i++)
        {
            for (int j = size * s; j < island.size() / size + size * s; j++)
            {
                cout << island.at(j)->render(i) << " ";
            }
            cout << endl;
        }
    }
}

int main()
{
    int size;
    vector<Tile*> island;
    
    cout << "Enter a value for 'n' between 4 and 7 to create an 'n' by 'n' island: ";
    cin >> size;
    
    while (size < 4 || size > 7)
    {
        cout << "INVALID SIZE" << endl;
        cout << "Enter a value for 'n' between 4 and 7 to create an 'n' by 'n' island: ";
        cin >> size;
    }
    
    buildIsland(island, size);
    renderIsland(island, size);
    
    
    return 0;
}