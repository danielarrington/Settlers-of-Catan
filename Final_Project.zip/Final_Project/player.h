#ifndef PLAYER_H
#define PLAYER_H

using namespace std;

class Player
{
    private:
        int wood;
        int bricks;
        int grain;
        int wool;
        int ore;
        
    public:
        Player(int wood, int bricks, int grain, int wool, int ore);
        
        int getWood();
        int getBricks();
        int getGrain();
        int getWool();
        int getOre();
        
        void modifyWood(int wd);
        void modifyBricks(int b);
        void modifyGrain(int g);
        void modifyWool(int wo);
        void modifyOre(int o);
    
};

#endif